<?php
$serverName = "localhost";
$username = "root";
$password = "";
$database = "wdv3411";

try {
    $conn = new PDO("mysql:host=$serverName;dbname=$database", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);		//Forces MySQL to create the PDO prepared statements instead of letting PDO make them.  Better SQL Injection protection
    echo "Connected successfully"; 	//TESTING ONLY!
    }
catch(PDOException $e)
    {
    	echo "Connection failed: " . $e->getMessage();	//TESTING ONLY!

		error_log($e->getMessage());			//Delivers a developer defined error message to the PHP log file at c:\xampp/php\logs\php_error_log
		error_log(var_dump(debug_backtrace()));
		
    }

?>