<?php

    $inEventName ="";
    $inEventDescription ="";
    $inEventPresenter ="";
    $inEventDate ="";
    $inEventTime ="";
	
	$event_name = "";
	$event_description = "";
	$event_presenter = "";
	$event_date = "";
	$event_time = "";

    $eventNameErrMsg ="";
    $eventDescriptionErrMsg ="";
    $eventPresenterErrMsg ="";
    $eventDateErrMsg ="";
    $eventTimeErrMsg ="";

	$validForm = true;		//set flag to true, assume all the data is valid

//JHGULLION Changed the value of the $_POST variable to 'button'.  This is the name of the Submit button on this form.  See line 129 <input type=submit...
//   Because this was looking for something called 'event_submit' it never thought the form was submitted.  Therefore it always assumed the form was to be displayed
//   to the user and never processed. 
//  if(isset($_POST["event_submit"]))  //original code looking for the Submit name attribute from a different form.  This is the problem when you use my code as written in your form.
    if(isset($_POST["button"]))	
  { 
    echo "<h1>Thank you for submitting the form.</h1>";
    
    $inEventName = $_POST["event_name"];
    $inEventDescription  = $_POST["event_description"];
    $inEventPresenter = $_POST["event_presenter"];
    $inEventTime = $_POST["event_time"];
    $inEventDate = $_POST["event_date"];

    if(isset($_POST['button'])){     //if radio is checked store value
      $inButton = $_POST["button"];     
    }


    echo "<p>event_name: $inEventName";
    echo "<p>event_description: $inEventDescription"; 
    echo "<p>event_presenter: $inEventPresenter";
    echo "<p>event_date: $inEventDate";
    echo "<p>event_time: $inEventTime";
    echo "<p>button: $inButton";
    
    //JHGULLION  Commented out the following line.  The $validForm variable should ONLY be set to false when a data validation function finds a problem with the data
	//This assignment is not doing data validation.  When you set this variable to false it says that the form data should NOT be inserted into the database.
	
    //$validForm = false;   //sets a flag/switch to make sure form data is valid
    //PHP validations go here

	//JHGULLION this if statement only runs if the $validForm variable is true.  You set it to false on line 42. Therefore this if statement was false and 
	//did not run the insertEvent.php file.
    if($validForm){
		//echo "<h1>Processing SQL</h1>";		
        include 'insertEventForm.php';
    }

    else {
      $eventNameErrMsg = "Invalid Name Field";
      $eventDescriptionErrMsg = "Wrong Description";
      $eventPresenterErrMsg = "Invalid Presenter";
      $eventDateErrMsg = "Enter Correct Date";
      $eventTimeErrMsg = "Incorrect Time";

      $eventButtonErrMsg = "Write your Details";
    }   
  }

  else {
    echo "<h1>Please enter your details.</h1>";
  }
  
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>WDV341 Intro PHP Form </title>


<style>

	#container	{
		width:960px;
		background-color:lightblue;
		margin:auto;
			
	}

</style>

</head>

<body>
	<div id="container">
        <h1>WDV341 Intro PHP</h1>
        <h2>Unit-6 SQL Insert</h2>
        <h3>Input Form Example</h3>
        <p>This form will gather information from the user. When submitted the form will call a server side PHP program. That program will use the form information to create and insert a record into the wdv341_event table in the database.</p>
		<!-- <form name="form1" method="post" action="insertEventForm.php">          -->
         <form name="form1" method="post" action="processEvents.php">
          <p>
            <label for="event_name">Event Name: </label>
              <input type="text" name="event_name" id="event_name" value="<?php echo $event_name; ?>">
            <span><?php echo $eventNameErrMsg; ?></span>
          </p>
		  
          <p>
            <label for="event_description">Event Description: </label>
              <input type="text" name="event_description" id="event_description" size="100" value="<?php echo $event_description; ?>">
            <span><?php echo $eventDescriptionErrMsg; ?></span>
          </p>
		  
		      <p>
            <label for="event_presenter">Event Presenter:  </label>
              <input type="text" name="event_presenter" id="event_presenter" size="100" value="<?php echo $event_presenter; ?>">
            <span><?php echo $eventPresenterErrMsg; ?></span>
		      </p>
		  
          <p>
            <label for="event_date">Event Date:  </label>
              <input type="date" name="event_date" id="event_date" value="<?php echo $event_date; ?>">
            <span><?php echo $eventDateErrMsg; ?></span>
          </p>
		  
          <p>
            <label for="event_time">Event Time:  </label>
              <input type="time" name="event_time" id="event_time" value="<?php echo $event_time; ?>">
            <span><?php echo $eventTimeErrMsg; ?></span>
          </p>
		  
          <p>
            <input type="submit" name="button" id="button" value="Submit">
            <input type="reset" name="button2" id="button2" value="Reset">
          </p>
        </form>
        <p>&nbsp;</p>
    </div>
</body>
</html>