<?php
$event_name ="";
$event_description ="";
$event_presenter ="";
$event_date ="";
$event_time ="";

if(isset($_POST['button']))
{
  $event_name = $_POST['event_name'];  
  $event_description = $_POST['event_description'];
  $event_presenter = $_POST['event_presenter'];
  $event_date = $_POST['event_date'];
  $event_time = $_POST['event_time'];

 }
try{
  require 'dbConnectRaymond.php';  
  
  //create insert commands to input data into the database
					$sql = "INSERT INTO wdv341_event(";
					$sql.= "event_name,";
					$sql.= "event_description,";
					$sql.= "event_presenter,";
					$sql.= "event_date,";
					$sql.= "event_time";
					$sql.= ")VALUES (:eventName, :eventDescription, :eventPresenter, :eventDate, :eventTime)";
					
					//PREPARE the SQL statement
				$statment = $conn->prepare($sql);
				
				//BIND the values to the input parameters of the prepared statement
				$statment->bindParam(':eventName', $event_name);
				$statment->bindParam(':eventDescription', $event_description);	
                $statment->bindParam(':eventPresenter', $event_presenter);				
				$statment->bindParam(':eventDate', $event_date);		
 				$statment->bindParam(':eventTime', $event_time);
					
				
				//EXECUTE the prepared statement
				$statment->execute();	
					
				}
				CATCH (PDOException $e)
					{
				$message = "There has been a problem. The system administrator has been contacted. Please try again later.";
	
				error_log($e->getMessage());			//Delivers a developer defined error message to the PHP log file at c:\xampp/php\logs\php_error_log
				error_log(var_dump(debug_backtrace()));
				
			
				header('Location: files/505_error_response_page.php');				
				}
   
?>