<?php
  include 'insertEventForm.php';
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>WDV341 Intro PHP Form </title>


<style>

	#container	{
		width:960px;
		background-color:lightblue;
		margin:auto;
			
	}

</style>

</head>

<body>
	<div id="container">
        <h1>WDV341 Intro PHP</h1>
        <h2>Unit-6 SQL Insert</h2>
        <h3>Input Form Example</h3>
        <p>This form will gather information from the user. When submitted the form will call a server side PHP program. That program will use the form information to create and insert a record into the wdv341_event table in the database.</p>
         <form name="form1" method="post" action="insertEventForm.php">
          <p>
            <label>Event Name:
              <input type="text" name="event_name" id="event_name" value="<?php echo $event_name; ?>">
            </label>
          </p>
		  
          <p>
            <label>Event Descript:
              <input type="text" name="event_description" id="event_description" size="100" value="<?php echo $event_description; ?>">
            </label>
          </p>
		  
		  <p>
            <label>Event Presenter:
              <input type="text" name="event_presenter" id="event_presenter" size="100" value="<?php echo $event_presenter; ?>">
            </label>
		  </p>
		  
          <p>
            <label>Event Date:
              <input type="date" name="event_date" id="event_date" value="<?php echo $event_date; ?>">
            </label>
          </p>
		  
          <p>
            <label>Event Time:
              <input type="time" name="event_time" id="event_time" value="<?php echo $event_time; ?>">
            </label>
          </p>
		  
          <p>
            <input type="submit" name="button" id="button" value="Submit">
            <input type="reset" name="button2" id="button2" value="Reset">
          </p>
        </form>
        <p>&nbsp;</p>
    </div>
</body>
</html>